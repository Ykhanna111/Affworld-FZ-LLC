# Ticket Support System

This is a simple Ticket Support System using FastAPI (backend), Vue.js (frontend), and MongoDB.

## Setup Instructions

### Backend (FastAPI)

1. Navigate to the `backend` directory:
   ```
   cd backend
   ```

2. Install the required dependencies:
   ```
   pip install fastapi uvicorn
   ```

3. Run the FastAPI server:
   ```
   uvicorn main:app --reload
   ```

### Frontend (Vue.js)

1. Navigate to the `frontend` directory:
   ```
   cd frontend
   ```

2. Install the required dependencies (Vue CLI):
   ```
   npm install
   ```

3. Run the Vue.js application:
   ```
   npm run serve
   ```

## Documentation

Refer to the `docs` directory for API documentation and additional information.
